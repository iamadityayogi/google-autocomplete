<?php
// phpinfo();
$abn = '51824753556'; // replace with the ABN number you want to check
$guid = 'c22a88ec-c24e-4920-aeb2-cd06c77318d3'; // replace with your GUID provided by the ABR
$client = new SoapClient('https://abr.business.gov.au/abrxmlsearch/ABRXMLSearch.asmx?WSDL');

$params = array(
  'searchString' => $abn,
  'includeHistoricalDetails' => 'N',
  'authenticationGuid' => $guid
);

$result = $client->ABRSearchByABN($params);
// print_r($result);die;
if ($result->ABRPayloadSearchResults->response->businessEntity->mainName->organisationName) {
  echo "Valid ABN number.";
} else {
  echo "Invalid ABN number.";
}

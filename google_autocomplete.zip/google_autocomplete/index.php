<!DOCTYPE html>
<html>
   <head>
      <title>Google Location Autocomplete using PHP and jQuery</title>
      <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
      <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyC-94El9frgOdBJdF8UnvFYWkBfTqTyp5Y&libraries=places"></script>
      <script>
         $(document).ready(function(){
            var options = {
               types: ['geocode'],
               componentRestrictions: {country: 'au'}
            };
            var autocomplete = new google.maps.places.Autocomplete(
               document.getElementById('location'), options);
            google.maps.event.addListener(autocomplete, 'place_changed', function() {
               var place = autocomplete.getPlace();
               var latitude = place.geometry.location.lat();
               var longitude = place.geometry.location.lng();
               console.log("Latitude: " + latitude);
               console.log("Longitude: " + longitude);
            });
         });
      </script>
      <script>
         $(document).ready(function(){
            var options = {
               types: ['geocode'],
               componentRestrictions: {country: 'au'}
            };
            var autocomplete = new google.maps.places.Autocomplete(
               document.getElementById('location2'), options);
            google.maps.event.addListener(autocomplete, 'place_changed', function() {
               var place = autocomplete.getPlace();
               var latitude = place.geometry.location.lat();
               var longitude = place.geometry.location.lng();
               console.log("Latitude: " + latitude);
               console.log("Longitude: " + longitude);
            });
         });
      </script>
   </head>
   <body>
      <input id="location" type="text" placeholder="Enter your location">
      <input id="location2" type="text" placeholder="Enter your location">
   </body>
</html>
